import logo from './logo.svg';
import './App.css';
import Crud from './components/crud';

function App() {
  return (
    <div className="App">
        <Crud />
    </div>
  );
}

export default App;
