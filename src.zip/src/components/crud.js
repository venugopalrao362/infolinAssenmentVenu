import React, { Component } from 'react'
import axios from 'axios'
import { Modal } from 'bootstrap';

class Crud extends Component {

    constructor(props) {
        super(props)

        this.state = {
            personList: [],
            editFlag: false,
            personName: "",
            personEmail: "",
            personPhone: "",
            personWebsite: "",
            personId: ""

        }
    }

    componentDidMount() {
        axios.get('https://jsonplaceholder.typicode.com/users').then((res) => {
            console.log(res.data);
            this.setState({ personList: res.data })
            // localStorage.clear()
            // localStorage.setItem('personList',res.data)
        })
    }

    editPerson(id) {
        var personList = [...this.state.personList]
        personList = personList.map((obj) => {

            if (obj.id === id) {
                return {
                    id: id,
                    name: this.state.personName,
                    email: this.state.personEmail,
                    phone: this.state.personPhone,
                    website: this.state.personWebsite
                }
            } else {
                return obj
            }


        
        })  
        console.log(personList);
        this.setState({ personList: personList, personId: "", personName: "", personEmail: "", personPhone: "", personWebsite: "", editFlag: false })
    }

removePerson(id) {
    if(window.confirm('Delete the item?')){
    var personList = [...this.state.personList]
    personList = personList.filter((obj) => {

        return obj.id !== id
    })

    this.setState({ personList })

}
}




render() {
    return (
        <div className="container">
            <div className="table-wrapper">
                <div className="table-title">
                    <h1>INFILON Assignment</h1>
                </div>
                <table className="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Website</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.personList.map((person) => {
                            if ((this.state.editFlag) && (this.state.personId === person.id))
                                return <tr key={person.id}>
                                    <td  > <input type="text" value={this.state.personName} onChange={(e) => this.setState({ personName: e.target.value })} /> </td>
                                    <td  > <input type="text" value={this.state.personEmail} onChange={(e) => this.setState({ personEmail: e.target.value })} /> </td>
                                    <td  > <input type="text" value={this.state.personPhone} onChange={(e) => this.setState({ personPhone: e.target.value })} /> </td>
                                    <td  > <input type="text" value={this.state.personWebsite} onChange={(e) => this.setState({ personWebsite: e.target.value })} /> </td>
                                    <td  >
                                        <div onClick={() => this.editPerson(person.id)} className="btn btn-success ml-2" title="Delete" data-toggle="tooltip"><i className="fa fa-save"></i> &nbsp; Save</div>
                                    </td>
                                </tr>
                            return <tr key={person.id}>

                                <td   >{person.name}</td>
                                <td  >{person.email}</td>
                                <td  >{person.phone}</td>
                                <td  >{person.website}</td>
                                <td  >

                                    <div onClick={() => this.setState({ editFlag: true, personName: person.name, personEmail: person.email, personPhone: person.phone, personWebsite: person.website, personId: person.id })} className="btn btn-primary" title="Edit" data-toggle="tooltip"><i className="fa fa-edit"></i></div>
                                    <div onClick={() => this.removePerson(person.id)} className="btn btn-danger ml-2" title="Delete" data-toggle="tooltip"><i className="fa fa-trash"></i></div>
                                </td>
                            </tr>


                        })}

                    </tbody>
                </table>
            </div>

        </div>
    )
}
}

export default Crud;
